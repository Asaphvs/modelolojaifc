-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 02-Dez-2017 às 09:31
-- Versão do servidor: 5.7.20-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loja_de_esportes`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `tb_produtos`
--

CREATE TABLE `tb_produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(32) NOT NULL,
  `categoria` varchar(32) NOT NULL,
  `preco` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `tb_produtos`
--

INSERT INTO `tb_produtos` (`id`, `nome`, `categoria`, `preco`) VALUES
(1, 'Penalty', 'Bola', '50.00'),
(2, 'Wilson', 'Bola', '100.00'),
(3, 'Adidas', 'Chuteira', '100.00'),
(4, 'Penalty', 'Chuteira', '100.00'),
(5, 'Umbro', 'Chuteira', '100.00'),
(6, 'Topper', 'Chuteira', '100.00'),
(7, 'Adidas', 'Chuteira', '100.00'),
(8, 'Nike', 'Chuteira', '100.00'),
(9, 'Camisa Real Madrid', 'Camisa', '150.00'),
(16, 'Camisa Barcelona', 'Camisa', '150.00'),
(17, 'Camisa Milan', 'Camisa', '130.00'),
(18, 'Camisa Brasil', 'Camisa', '150.00'),
(19, 'Camisa Manchester united', 'Camisa', '130.00'),
(20, 'Camisa Paris Saint Germain', 'Camisa', '130.00'),
(21, 'Moletom IFC Voleibol', 'Moletom', '75.00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_produtos`
--
ALTER TABLE `tb_produtos`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_produtos`
--
ALTER TABLE `tb_produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
