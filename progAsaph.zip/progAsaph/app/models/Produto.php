<?php

require_once "Conexao.php";
require_once "CrudProdutos.php";

class Produto {

    public $id;
    public $nome;
    public $preco;
    public $estoque;//estoque
    public $categoria;

    public function __construct($nome, $preco, $estoque, $categoria, $id = null){ //estoque
        $this->id = $id;
        $this->nome = $nome;
        $this->preco = $preco;
        $this->estoque = $estoque;
        $this->categoria = $categoria;
    }

    public function estaDisponivel(){
        // o estqoeu for maior que zero retorna disponivel
        if ( $this ->estoque > 0 ){
            echo 'Está disponivel';
        }
        else echo 'Indisponível';
    }

    public function comprar(){
        if ($_POST == "1" ){
            if ($this -> estoque >0)
            $this ->estoque --;
        }
        else die();
    }
}

